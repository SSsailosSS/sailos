<?php

// User data
return [
    [
        'id' => 1,
        'name' => 'Chikmarev Sergey',
        'email' => '4SVOboda@example.com',
        'type' => 'admin'
    ],
    [
        'id' => 2,
        'name' => 'Lolo Lali',
        'email' => 'LoLa@example.com',
        'type' => 'customer'
    ],
    [
        'id' => 3,
        'name' => 'Biba Boba',
        'email' => 'boba.bibip@example.com',
        'type' => 'customer'
    ],
    [
        'id' => 4,
        'name' => 'Daniel Williams',
        'email' => 'alice.williams@example.com',
        'type' => 'manager'
    ],
    [
        'id' => 5,
        'name' => 'Simon White',
        'email' => 'charlie.brown@example.com',
        'type' => 'customer'
    ]
]; 