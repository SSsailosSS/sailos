# User List

| ID | Name | Email | Type |
|:---|:-----|:------|:-----|
| 1 | Chikmarev Sergey | 4SVOboda@example.com | admin |
| 2 | Lolo Lali | LoLa@example.com | customer |
| 3 | Biba Boba | boba.bibip@example.com | customer |
| 4 | Daniel Williams | alice.williams@example.com | manager |
| 5 | Simon White | charlie.brown@example.com | customer |

## Summary

Total users: **5**

### User Types:

* **Admin**: 1
* **Customer**: 3
* **Manager**: 1
